#Create Repository
aws ecr create-repository --repository-name northpark --image-scanning-configuration scanOnPush=true

